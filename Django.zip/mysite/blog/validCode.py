# -*- coding: utf-8 -*-

from PIL import Image, ImageDraw, ImageFont
import random
from io import BytesIO


def set_validCode(request):
    # 获取一个背景色填充验证码生成区
    def get_color():
        R = random.randint(0, 220)
        G = random.randint(0, 220)
        B = random.randint(0, 220)
        color = (R, G, B)
        return color

    width = 250
    height = 34
    img = Image.new('RGB', (width, height), color=(255, 255, 240))  # 使用PIL生成一张图片
    dram = ImageDraw.ImageDraw(img)  # 创建画板
    fonts = ImageFont.truetype("static/blog/fonts/SIMLI.TTF", size=28)
    validCode = ''  # 保存验证码
    # 生成随机数
    for i in range(5):
        numbers = str(random.randint(0, 9))  # 随机生成数字
        apl_upper = chr(random.randint(65, 90))  # 随机生成大写字母
        apl_lower = chr(random.randint(95, 122))  # 随机生成小写字母
        valid_text = random.choice([numbers, apl_lower, apl_upper])
        dram.text((30 * i + 35, 2), valid_text, get_color(), font=fonts)
        validCode += valid_text
    # 生成随机线条
    for item in range(8):
        x1 = random.randint(0, width)
        x2 = random.randint(0, width)
        y1 = random.randint(0, height)
        y2 = random.randint(0, height)
        dram.line((x1, y1, x2, y2), fill=get_color())

    # 生成随机点
    for item in range(50):
        dram.point([random.randint(0, width), random.randint(0, height)], fill=get_color())
        x = random.randint(0, width)
        y = random.randint(0, height)
        dram.arc((x, y, x + 4, y + 4), 0, 90, fill=get_color())

    request.session['validCode'] = validCode    #将验证码存放在django的session中
    f = BytesIO()  # 创建内存流
    img.save(f, 'png')  # 使用内存器缓存图片
    data = f.getvalue()
    return data

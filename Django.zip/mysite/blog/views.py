from django.db.models import Count
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import auth

from blog.models import *
from blog.validCode import set_validCode
from blog.reg_forms import UserFrom
import datetime


# Create your views here.

def index(request):
    art_list = Article.objects.all()
    cat_list = Category.objects.all()
    tag_list = Tag.objects.all()
    return render(request, 'index.html', {'art_list': art_list, 'cat_list': cat_list, 'tag_list': tag_list})


# 登录验证
def login(request):
    if request.method == 'POST':
        response = {'user': None, 'msg': None}  # 验证后返回验证信息
        user = request.POST.get('user')
        pwd = request.POST.get('pwd')
        valid_code = request.POST.get('valid')  # 获取用户输入的验证码
        validCode = request.session.get('validCode')  # 从session中取出验证码
        if valid_code.lower() == validCode.lower():
            user = auth.authenticate(username=user, password=pwd)
            if user:
                auth.login(request, user=user)  # 如果成功,将当前user存储到session中
                response['user'] = user.username
            else:
                response['msg'] = "用户名或密码错误！！"
        else:
            response['msg'] = "验证码错误!"
        return JsonResponse(response)
    return render(request, 'login.html')


# #login.html中验证码的生成
def get_valid_code(request):
    data = set_validCode(request)
    return HttpResponse(data)


# 注册信息
def register(request):
    if request.method == 'POST':
        response = {'user': None, 'msg': None}
        form = UserFrom(request.POST)
        if form.is_valid():
            user = form.cleaned_data.get('user')
            pwd = form.cleaned_data.get('password')
            email = form.cleaned_data.get('email')
            UserInfo.objects.create_user(username=user, password=pwd, email=email)
        else:
            response['msg'] = form.errors
        return JsonResponse(response)
    form = UserFrom()
    return render(request, 'register.html', {'form': form})


# 注销登录
def logout(request):
    auth.logout(request)
    return redirect('/')


# 设置个人博客站点
def blog_site(request, username):
    user = UserInfo.objects.filter(username=username).first()  # 获取当前用户名
    if not user:
        return render(request, 'page_404.html')  # 用户不存在返回404

    blog = user.blog  # 获取当前站点的站点信息

    """
    # 通过过滤器检索指定对象,和Article.objects.filter(user=user)一样
    # articles = user.article_set.all()

    # 查询每一个分类对应的文章数
    # cats = Category.objects.values('pk').annotate(
    #     c=Count('article__title')).values('title', 'c')
    """
    # 查询站点所有文章
    art_list = Article.objects.filter(user=user)

    # 查询每一个站点当前的分类对应的文章数
    cat_user = Category.objects.filter(blog=blog).values('pk').annotate(
        c=Count('article__title')).values_list('title', 'c')

    # 查询每一个站点当前的标签对应的文章数
    tag_user = Tag.objects.filter(blog=blog).values('pk').annotate(
        c=Count('article__title')).values_list('title', 'c')

    # 以时间截来分类显示当前用户的文章
    # 方法1：
    art_time = Article.objects.filter(user=user).extra(
        select={"art_time": "date_format(create_time,'%%Y-%%m')"}). \
        values_list('art_time').annotate(c=Count('pk')).values_list('art_time', 'c')
    # 方法2：
    """
    from django.db.models.functions import TruncMonth
    art_month = Article.objects.filter(user=user).annotate(month=TruncMonth('create_time')).values('month').annotate(c=Count('month')).values('month', 'c')
    """
    return render(request, 'blog_site.html',
                  {'user': user, 'art_list': art_list, 'blog': blog, 'cat_user': cat_user, 'tag_user': tag_user,
                   'art_time': art_time})


# 点击文章标题显示文章内容
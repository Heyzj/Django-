# -*- coding: utf-8 -*-

from django import forms
from django.forms import widgets
from django.core.exceptions import ValidationError
from blog.models import UserInfo


# 使用基于django.forms组件注册信息
class UserFrom(forms.Form):
    user = forms.CharField(max_length=15,
                           min_length=4,
                           label="用户名",
                           error_messages={
                               "required": "用户名不能为空！",
                               "max_length": "用户名不少于4位!",
                               "min_length": "用户名不超过15位!"
                           },
                           widget=widgets.TextInput(attrs={
                               "class": "form-control",
                               "placeholder": "请输入用户名(4-15位不含特殊符号)",
                           }, )
                           )
    password = forms.CharField(max_length=20,
                               min_length=8,
                               label="用户密码",
                               error_messages={
                                   'min_length': '密码最少为8位',
                                   'max_length': '密码最多20位',
                                   'required': '密码不能为空'
                               },
                               widget=widgets.PasswordInput(attrs={
                                   "class": "form-control",
                                   "placeholder": "请输入密码(8-20位)",
                               })
                               )
    re_password = forms.CharField(max_length=20,
                                  min_length=8,
                                  label="确认密码",
                                  error_messages={
                                      'min_length': '密码最少为8位!',
                                      'max_length': '密码最多20位!',
                                      'required': '密码不能为空!'
                                  },
                                  widget=widgets.PasswordInput(attrs={
                                      "class": "form-control",
                                      "placeholder": "请再次确认密码",
                                  })
                                  )
    email = forms.EmailField(max_length=32,
                             min_length=5,
                             label="邮箱",
                             error_messages={
                                 'invalid': '邮箱格式不对，请重新输入',
                                 'required': '邮箱不能为空!'
                             },
                             widget=widgets.EmailInput(attrs={
                                 "class": "form-control",
                                 "placeholder": "请输入邮箱",
                             })
                             )

    # 验证用户名是否存在,(使用全局钩子必须使用clean_开始)
    def clean_user(self):
        users = self.cleaned_data.get('user')
        user = UserInfo.objects.filter(username=users).first()
        if not user:
            return users
        else:
            raise ValidationError("该用户名已经被注册！")

    # 验证两次输入的密码是否一致
    def clean(self):
        pwd = self.cleaned_data.get('password')
        re_pwd = self.cleaned_data.get('re_password')
        if pwd and re_pwd:
            if pwd == re_pwd:
                return self.cleaned_data
            else:
                raise ValidationError("两次输入的密码不一致！")
        else:
            return self.cleaned_data

from django.db import models
from django.contrib.auth.models import User, AbstractUser


# Create your models here.
# 用户表
class UserInfo(AbstractUser):
    uid = models.AutoField(primary_key=True)  # 主键id
    phone = models.CharField(max_length=11, unique=True, null=None)  # 用户电话
    avatar = models.FileField(upload_to='avatars/', default='/avatars/default.png')  # 用户头像
    create_time = models.DateTimeField(verbose_name='创建时间', auto_now_add=True)  # 创建时间

    blog = models.OneToOneField(to='Blog', to_field='uid', null=True, on_delete=models.CASCADE)  # 外键(一对一)

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = "用户"
        verbose_name_plural = verbose_name


# blog个人站点
class Blog(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键pk
    title = models.CharField(max_length=100, verbose_name='博客标题')  # 博客标题
    blog_name = models.CharField(max_length=64, verbose_name='个人站点名称')  # 个人站点名称
    theme = models.CharField(max_length=64, verbose_name='博客主题')  # 博客主题

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "个人站点"
        verbose_name_plural = verbose_name


# 个人blog分类(随笔分类)
class Category(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    title = models.CharField(max_length=64, verbose_name='分类')  # 分类

    blog = models.ForeignKey(to='Blog', to_field='uid', verbose_name='所属博客', on_delete=models.CASCADE)  # 外键(一对多)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "随笔分类"
        verbose_name_plural = verbose_name


# 个人blog标签(标签)
class Tag(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    title = models.CharField(max_length=32, verbose_name='标签')  # 分类标签

    blog = models.ForeignKey(to='Blog', to_field='uid', verbose_name='所属博客', on_delete=models.CASCADE)  # 外键(一对多)

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "标签"
        verbose_name_plural = verbose_name


# blog内容表
class Article(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    title = models.CharField(max_length=100, verbose_name='文章标题')  # 文章标题
    desc = models.CharField(max_length=255, verbose_name='文章摘要')  # 文章摘要
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='文章创建时间')  # 文章创建时间
    comment_count = models.IntegerField(default=0, verbose_name='评论数')  # 评论数
    up_count = models.IntegerField(default=0, verbose_name='点赞数')  # 点赞数
    down_count = models.IntegerField(default=0, verbose_name='踩踏数')  # 踩踏数
    content = models.TextField()  # 文章内容

    user = models.ForeignKey(to='UserInfo', to_field='uid', verbose_name='作者', on_delete=models.CASCADE)  # 外键
    category = models.ManyToManyField(
        to='Category',
        through='Article2Category',
        through_fields=('article', 'category'),
    )
    tag = models.ManyToManyField(
        to='Tag',
        through='Article2Tag',
        through_fields=('article', 'tag'),
    )

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = "博客内容"
        verbose_name_plural = verbose_name


# 内容表和分类表的中间表
class Article2Category(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    article = models.ForeignKey(to='Article', to_field='uid', verbose_name='文章', on_delete=models.CASCADE)
    category = models.ForeignKey(to='Category', to_field='uid', verbose_name='分类', on_delete=models.CASCADE)

    class Meta:
        unique_together = [
            ('article', 'category'),
        ]

    def __str__(self):
        re = self.article.title + "----" + self.category.title
        return re

    class Meta:
        verbose_name = "内容分类"
        verbose_name_plural = verbose_name


# 内容表和标签表的中间表
class Article2Tag(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    article = models.ForeignKey(to='Article', to_field='uid', verbose_name='文章', on_delete=models.CASCADE)
    tag = models.ForeignKey(to='Tag', to_field='uid', verbose_name='标签', on_delete=models.CASCADE)

    class Meta:
        unique_together = [
            ('article', 'tag'),
        ]
        verbose_name = "内容标签"
        verbose_name_plural = verbose_name

    def __str__(self):
        res = self.article.title + "----" + self.tag.title
        return res


# 用户点赞表
class ArticleUpDown(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    user = models.ForeignKey(to='UserInfo', null=True, on_delete=models.CASCADE,verbose_name='谁点的赞')  # 谁点的赞
    article = models.ForeignKey(to='Article', null=True, on_delete=models.CASCADE,verbose_name='点赞的文章')  # 点赞的文章
    is_up = models.BooleanField(default=True, verbose_name='是否点赞')  # 是否点赞

    class Meta:
        unique_together = [
            ('user', 'article'),
        ]
        verbose_name = "点赞"
        verbose_name_plural = verbose_name


# 用户评论表
class Comment(models.Model):
    uid = models.AutoField(primary_key=True)  # 主键id
    user = models.ForeignKey(to='UserInfo', null=True, verbose_name='评论者', on_delete=models.CASCADE)  # 谁点的赞
    article = models.ForeignKey(to='Article', null=True, verbose_name='评论文章', on_delete=models.CASCADE)  # 点赞的文章
    create_time = models.DateTimeField(auto_now_add=True, verbose_name='评论时间')  # 文章创建时间
    content = models.CharField(max_length=255, verbose_name='评论内容')  # 评论内容
    parent_comment = models.ForeignKey('self', null=True, verbose_name='评论者ID', on_delete=models.CASCADE)  # 存储根评论的id

    def __str__(self):
        return self.content

    class Meta:
        verbose_name = "评论"
        verbose_name_plural = verbose_name

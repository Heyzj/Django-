# -*- coding: utf-8 -*-

from django.urls import path, re_path
from . import views

urlpatterns = [
    re_path('^$', views.index),
    path('login/', views.login),
    path('get_valid_code/', views.get_valid_code),
    path('register/', views.register),
    path('logout/', views.logout),

    re_path('^(?P<username>\w+)$', views.blog_site),  # 个人博客站点路由
]
